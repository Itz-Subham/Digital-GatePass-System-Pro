package com.example.gatepass;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.ArrayList;
import java.util.List;

public class ActiveVisitorsActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private VisitorAdapter adapter;
    private List<Visitor> visitorList;
    private FirebaseFirestore db;
    private SearchView searchView;
    private View llEmptyState;
    private View progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);

        TextView tvTitle = findViewById(R.id.tvTitle);
        tvTitle.setText("Active Visitors");

        recyclerView = findViewById(R.id.recyclerView);
        searchView = findViewById(R.id.searchView);
        llEmptyState = findViewById(R.id.llEmptyState);
        progressBar = findViewById(R.id.progressBar);
        ImageView btnBack = findViewById(R.id.btnBack);

        btnBack.setOnClickListener(v -> finish());

        visitorList = new ArrayList<>();
        adapter = new VisitorAdapter(visitorList);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        db = FirebaseFirestore.getInstance();
        fetchActiveVisitors();

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                adapter.filter(query);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                adapter.filter(newText);
                return false;
            }
        });
    }

    private void fetchActiveVisitors() {
        progressBar.setVisibility(View.VISIBLE);
        db.collection(Constants.COL_VISITORS)
                .whereEqualTo("status", Constants.STATUS_INSIDE)
                .addSnapshotListener((value, error) -> {
                    progressBar.setVisibility(View.GONE);
                    if (error != null) {
                        Toast.makeText(this, "Error fetching data", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    visitorList.clear();
                    if (value != null) {
                        for (QueryDocumentSnapshot doc : value) {
                            Visitor visitor = doc.toObject(Visitor.class);
                            visitorList.add(visitor);
                        }
                    }
                    adapter.updateList(new ArrayList<>(visitorList));
                    llEmptyState.setVisibility(visitorList.isEmpty() ? View.VISIBLE : View.GONE);
                });
    }
}
