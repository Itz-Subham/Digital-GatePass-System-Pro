package com.example.gatepass;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;

public class GatePassPreviewActivity extends AppCompatActivity {

    private ImageView ivHandshakeQr;
    private TextView previewStudentName, previewStudentReg, previewParentName, previewEntryTime, tvDocIdDisplay;
    private String documentId, studentName, studentReg, parentName, entryTime;
    private MaterialButton btnPrint;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gate_pass_preview);

        // Bindings
        ivHandshakeQr = findViewById(R.id.ivHandshakeQr);
        previewStudentName = findViewById(R.id.previewStudentName);
        previewStudentReg = findViewById(R.id.previewStudentReg);
        previewParentName = findViewById(R.id.previewParentName);
        previewEntryTime = findViewById(R.id.previewEntryTime);
        tvDocIdDisplay = findViewById(R.id.tvDocIdDisplay);
        MaterialButton btnSharePass = findViewById(R.id.btnSharePass);
        MaterialButton btnDone = findViewById(R.id.btnDone);
        btnPrint = findViewById(R.id.btnPrint);

        // Get Data from Intent
        studentName = getIntent().getStringExtra("STUDENT_NAME");
        studentReg = getIntent().getStringExtra("STUDENT_REG");
        parentName = getIntent().getStringExtra("PARENT_NAME");
        entryTime = getIntent().getStringExtra("ENTRY_TIME");
        documentId = getIntent().getStringExtra("DOCUMENT_ID");

        // Set Preview Details
        previewStudentName.setText(studentName);
        previewStudentReg.setText("Reg No: " + studentReg);
        previewParentName.setText("Parent: " + parentName);
        previewEntryTime.setText("Entry Time: " + entryTime);
        if (documentId != null) {
            tvDocIdDisplay.setText("ID: " + documentId);
        }

        // Stage One: Generate Handshake QR (Updated to your official base URL)
        if (documentId != null) {
            String handshakeUrl = "https://gate-pass-generator-6f165.web.app?id=" + documentId;
            Bitmap qrBitmap = generateQRCode(handshakeUrl);
            if (qrBitmap != null) {
                ivHandshakeQr.setImageBitmap(qrBitmap);
            }
        }

        btnSharePass.setOnClickListener(v -> sharePassAsImage());
        btnDone.setOnClickListener(v -> navigateToHome());
        btnPrint.setOnClickListener(v -> printPass());

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                navigateToHome();
            }
        });
    }

    private void printPass() {
        Visitor visitor = new Visitor(parentName, "", studentReg, studentName, entryTime, "pending", System.currentTimeMillis());
        PrintManager.printGatePass(this, visitor, documentId);
    }

    private void sharePassAsImage() {
        View view = LayoutInflater.from(this).inflate(R.layout.view_gate_pass_slip, null);
        
        ((TextView) view.findViewById(R.id.slipStudentName)).setText("Student: " + studentName);
        ((TextView) view.findViewById(R.id.slipStudentReg)).setText("Reg: " + studentReg);
        ((TextView) view.findViewById(R.id.slipParentName)).setText("Parent: " + parentName);
        ((TextView) view.findViewById(R.id.slipEntryTime)).setText("Time: " + entryTime);
        ((TextView) view.findViewById(R.id.slipDocId)).setText("ID: " + documentId);
        
        ImageView ivQr = view.findViewById(R.id.slipQrCode);
        Bitmap qrBitmap = generateQRCode(documentId);
        if (qrBitmap != null) {
            ivQr.setImageBitmap(qrBitmap);
        }

        // Use high-resolution measurement for sharing
        view.measure(View.MeasureSpec.makeMeasureSpec(1000, View.MeasureSpec.EXACTLY),
                     View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED));
        view.layout(0, 0, view.getMeasuredWidth(), view.getMeasuredHeight());

        Bitmap bitmap = Bitmap.createBitmap(view.getMeasuredWidth(), view.getMeasuredHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        view.draw(canvas);

        String path = MediaStore.Images.Media.insertImage(getContentResolver(), bitmap, "GatePass_" + studentReg, "Digital Gate Pass");
        if (path != null) {
            Uri uri = Uri.parse(path);
            Intent shareIntent = new Intent(Intent.ACTION_SEND);
            shareIntent.setType("image/*");
            shareIntent.putExtra(Intent.EXTRA_STREAM, uri);
            shareIntent.putExtra(Intent.EXTRA_TEXT, "Digital Hallpass for " + studentName);
            startActivity(Intent.createChooser(shareIntent, "Share Hallpass"));
        } else {
            Toast.makeText(this, "Failed to generate image", Toast.LENGTH_SHORT).show();
        }
    }

    private void navigateToHome() {
        Intent intent = new Intent(this, DashboardActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
        finish();
    }

    private Bitmap generateQRCode(String text) {
        QRCodeWriter writer = new QRCodeWriter();
        try {
            BitMatrix bitMatrix = writer.encode(text, BarcodeFormat.QR_CODE, 512, 512);
            int width = bitMatrix.getWidth();
            int height = bitMatrix.getHeight();
            Bitmap bmp = Bitmap.createBitmap(width, height, Bitmap.Config.RGB_565);
            for (int x = 0; x < width; x++) {
                for (int y = 0; y < height; y++) {
                    bmp.setPixel(x, y, bitMatrix.get(x, y) ? Color.BLACK : Color.WHITE);
                }
            }
            return bmp;
        } catch (WriterException e) {
            return null;
        }
    }
}
