package com.example.gatepass;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.print.PrintHelper;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.journeyapps.barcodescanner.BarcodeEncoder;

public class DisplayQrActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_qr);

        // Bindings
        MaterialCardView gatePassCard = findViewById(R.id.gatePassCard);
        TextView tvStudentName = findViewById(R.id.tvStudentName);
        TextView tvStudentReg = findViewById(R.id.tvStudentReg);
        TextView tvEntryTime = findViewById(R.id.tvEntryTime);
        TextView tvDocId = findViewById(R.id.tvDocId);
        ImageView qrImageView = findViewById(R.id.qrImageView);
        
        MaterialButton btnPrintPass = findViewById(R.id.btnPrintPass);
        MaterialButton btnFinish = findViewById(R.id.btnFinish);

        // Get Data from Intent
        String studentName = getIntent().getStringExtra("STUDENT_NAME");
        String studentReg = getIntent().getStringExtra("STUDENT_REG");
        String entryTime = getIntent().getStringExtra("ENTRY_TIME");
        String documentId = getIntent().getStringExtra("DOCUMENT_ID");

        // Populate Native UI
        if (studentName != null) tvStudentName.setText(studentName);
        if (studentReg != null) tvStudentReg.setText("Reg: " + studentReg);
        if (entryTime != null) tvEntryTime.setText("Entry: " + entryTime);
        if (documentId != null) {
            String trimmedId = documentId.trim();
            tvDocId.setText("ID: " + trimmedId);
            
            // Generate QR Code with exact URL and trimmed ID
            String finalUrl = "https://gate-pass-generator-6f165.web.app?id=" + trimmedId;
            generateQr(finalUrl, qrImageView);
        }

        // Native Printing Logic
        btnPrintPass.setOnClickListener(v -> {
            printNativeCard(gatePassCard, studentReg != null ? studentReg : "pass");
        });

        btnFinish.setOnClickListener(v -> {
            Intent intent = new Intent(this, DashboardActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            finish();
        });
    }

    private void printNativeCard(View view, String regNo) {
        // Capture the CardView as a Bitmap
        Bitmap bitmap = Bitmap.createBitmap(view.getWidth(), view.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        view.draw(canvas);

        // Send to PrintHelper
        PrintHelper printHelper = new PrintHelper(this);
        printHelper.setScaleMode(PrintHelper.SCALE_MODE_FIT);
        printHelper.printBitmap("GatePass_" + regNo, bitmap);
    }

    private void generateQr(String url, ImageView imageView) {
        MultiFormatWriter writer = new MultiFormatWriter();
        try {
            BitMatrix matrix = writer.encode(url, BarcodeFormat.QR_CODE, 512, 512);
            BarcodeEncoder encoder = new BarcodeEncoder();
            Bitmap bitmap = encoder.createBitmap(matrix);
            imageView.setImageBitmap(bitmap);
        } catch (WriterException e) {
            e.printStackTrace();
        }
    }
}