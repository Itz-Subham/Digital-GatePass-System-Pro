package com.example.gatepass;

import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;

public class HallpassSimulationActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hallpass_simulation);

        TextView tvStudentName = findViewById(R.id.tvStudentName);
        TextView tvStudentReg = findViewById(R.id.tvStudentReg);
        TextView tvEntryTime = findViewById(R.id.tvEntryTime);
        ImageView ivCheckoutQr = findViewById(R.id.ivCheckoutQr);

        String name = getIntent().getStringExtra("STUDENT_NAME");
        String reg = getIntent().getStringExtra("STUDENT_REG");
        String entry = getIntent().getStringExtra("ENTRY_TIME");
        String docId = getIntent().getStringExtra("DOCUMENT_ID");

        tvStudentName.setText(name);
        tvStudentReg.setText("Reg: " + reg);
        tvEntryTime.setText("Entered at " + entry);

        // Stage Two: Generate Checkout QR (Strict Document ID)
        if (docId != null) {
            Bitmap qrBitmap = generateQRCode(docId);
            if (qrBitmap != null) {
                ivCheckoutQr.setImageBitmap(qrBitmap);
            }
        }
    }

    private Bitmap generateQRCode(String text) {
        QRCodeWriter writer = new QRCodeWriter();
        try {
            BitMatrix bitMatrix = writer.encode(text, BarcodeFormat.QR_CODE, 512, 512);
            int width = bitMatrix.getWidth();
            int height = bitMatrix.getHeight();
            Bitmap bmp = Bitmap.createBitmap(width, height, Bitmap.Config.RGB_565);
            for (int x = 0; x < width; x++) {
                for (int y = 0; y < height; y++) {
                    bmp.setPixel(x, y, bitMatrix.get(x, y) ? Color.BLACK : Color.WHITE);
                }
            }
            return bmp;
        } catch (WriterException e) {
            return null;
        }
    }
}
