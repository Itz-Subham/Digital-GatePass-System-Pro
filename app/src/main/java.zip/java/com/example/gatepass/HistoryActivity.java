package com.example.gatepass;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget   .SwipeRefreshLayout;

import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.ArrayList;
import java.util.List;

public class HistoryActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private VisitorAdapter adapter;
    private List<Visitor> visitorList;
    private FirebaseFirestore db;
    private SearchView searchView;
    private SwipeRefreshLayout swipeRefreshLayout;
    private View llEmptyState;
    private View progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);

        TextView tvTitle = findViewById(R.id.tvTitle);
        tvTitle.setText("Visitor History");

        recyclerView = findViewById(R.id.recyclerView);
        searchView = findViewById(R.id.searchView);
        swipeRefreshLayout = findViewById(R.id.swipeRefreshLayout);
        llEmptyState = findViewById(R.id.llEmptyState);
        progressBar = findViewById(R.id.progressBar);
        ImageView btnBack = findViewById(R.id.btnBack);

        btnBack.setOnClickListener(v -> finish());

        visitorList = new ArrayList<>();
        adapter = new VisitorAdapter(visitorList);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        db = FirebaseFirestore.getInstance();
        fetchHistory();

        swipeRefreshLayout.setOnRefreshListener(this::fetchHistory);

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                adapter.filter(query);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                adapter.filter(newText);
                return false;
            }
        });
    }

    private void fetchHistory() {
        if (!swipeRefreshLayout.isRefreshing()) progressBar.setVisibility(View.VISIBLE);
        db.collection(Constants.COL_VISITORS)
                .orderBy("timestamp", Query.Direction.DESCENDING)
                .limit(50) // Performance: Limit history fetch
                .get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    visitorList.clear();
                    for (QueryDocumentSnapshot doc : queryDocumentSnapshots) {
                        Visitor visitor = doc.toObject(Visitor.class);
                        visitorList.add(visitor);
                    }
                    adapter.updateList(new ArrayList<>(visitorList));
                    
                    llEmptyState.setVisibility(visitorList.isEmpty() ? View.VISIBLE : View.GONE);
                    progressBar.setVisibility(View.GONE);
                    swipeRefreshLayout.setRefreshing(false);
                })
                .addOnFailureListener(e -> {
                    progressBar.setVisibility(View.GONE);
                    swipeRefreshLayout.setRefreshing(false);
                    Toast.makeText(this, "Network error: check connection", Toast.LENGTH_SHORT).show();
                });
    }
}
