package com.example.gatepass;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.OptIn;
import androidx.appcompat.app.AppCompatActivity;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.ExperimentalGetImage;
import androidx.camera.core.ImageAnalysis;
import androidx.camera.core.ImageProxy;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.core.content.ContextCompat;

import com.google.android.material.button.MaterialButton;
import com.google.common.util.concurrent.ListenableFuture;
import com.google.mlkit.vision.barcode.BarcodeScanner;
import com.google.mlkit.vision.barcode.BarcodeScannerOptions;
import com.google.mlkit.vision.barcode.BarcodeScanning;
import com.google.mlkit.vision.barcode.common.Barcode;
import com.google.mlkit.vision.common.InputImage;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class CheckoutScannerActivity extends AppCompatActivity {

    private PreviewView viewFinder;
    private BarcodeScanner scanner;
    private boolean isProcessing = false;
    private FirebaseFirestore db;
    private ExecutorService analysisExecutor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_checkout_scanner);

        viewFinder = findViewById(R.id.viewFinder);
        MaterialButton btnManualCheckout = findViewById(R.id.btnManualCheckout);
        ImageView btnBack = findViewById(R.id.btnBack);
        
        btnBack.setOnClickListener(v -> finish());
        
        btnManualCheckout.setOnClickListener(v -> {
            Intent intent = new Intent(this, ManualSelectionActivity.class);
            intent.putExtra("ACTION", ManualSelectionActivity.ACTION_CHECKOUT);
            startActivity(intent);
        });

        db = FirebaseFirestore.getInstance();

        BarcodeScannerOptions options = new BarcodeScannerOptions.Builder()
                .setBarcodeFormats(Barcode.FORMAT_QR_CODE)
                .build();
        scanner = BarcodeScanning.getClient(options);
        analysisExecutor = Executors.newSingleThreadExecutor();

        startCamera();
    }

    private void startCamera() {
        ListenableFuture<ProcessCameraProvider> future = ProcessCameraProvider.getInstance(this);
        future.addListener(() -> {
            try {
                ProcessCameraProvider cameraProvider = future.get();
                Preview preview = new Preview.Builder().build();
                preview.setSurfaceProvider(viewFinder.getSurfaceProvider());

                ImageAnalysis imageAnalysis = new ImageAnalysis.Builder()
                        .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                        .build();

                imageAnalysis.setAnalyzer(analysisExecutor, this::processImageProxy);

                cameraProvider.unbindAll();
                cameraProvider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview, imageAnalysis);

            } catch (ExecutionException | InterruptedException e) {
                Log.e("CheckoutScanner", "Camera failed", e);
            }
        }, ContextCompat.getMainExecutor(this));
    }

    @OptIn(markerClass = ExperimentalGetImage.class)
    private void processImageProxy(ImageProxy imageProxy) {
        if (isProcessing || imageProxy.getImage() == null) {
            imageProxy.close();
            return;
        }

        InputImage image = InputImage.fromMediaImage(imageProxy.getImage(), imageProxy.getImageInfo().getRotationDegrees());

        scanner.process(image)
                .addOnSuccessListener(barcodes -> {
                    for (Barcode barcode : barcodes) {
                        String rawValue = barcode.getRawValue();
                        if (rawValue != null) {
                            String docId = extractDocId(rawValue);
                            if (docId != null) {
                                navigateToDetail(docId);
                                break;
                            }
                        }
                    }
                })
                .addOnCompleteListener(task -> imageProxy.close());
    }

    private String extractDocId(String rawValue) {
        if (rawValue == null || rawValue.isEmpty()) return null;

        String result = rawValue.trim();

        // 1. Handle the new Web-App URL format
        String webPrefix = Constants.BASE_QR_URL;
        if (result.contains(webPrefix)) {
            result = result.substring(result.indexOf(webPrefix) + webPrefix.length());
        }
        // Also handle the URL without 'www' or slightly different variations if they exist
        else if (result.contains("gate-pass-generator-6f165.web.app?id=")) {
             String altPrefix = "gate-pass-generator-6f165.web.app?id=";
             result = result.substring(result.indexOf(altPrefix) + altPrefix.length());
        }

        // 2. Remove any remaining URL parts if it was a full URL but didn't match prefix exactly
        if (result.contains("id=")) {
            result = result.substring(result.indexOf("id=") + 3);
        }
        
        // 3. Clean up any trailing parameters or slashes
        if (result.contains("&")) {
            result = result.substring(0, result.indexOf("&"));
        }
        if (result.endsWith("/")) {
            result = result.substring(0, result.length() - 1);
        }

        // 4. Handle the "Portable Data" format (fallback)
        if (result.startsWith("ID:")) {
            int pipeIndex = result.indexOf("|");
            if (pipeIndex != -1) {
                result = result.substring(3, pipeIndex);
            } else {
                result = result.substring(3);
            }
        }
        
        return result.trim();
    }

    private void navigateToDetail(String docId) {
        if (isProcessing || docId == null || docId.isEmpty()) return;
        isProcessing = true;
        
        try {
            Intent intent = new Intent(this, CheckoutDetailActivity.class);
            intent.putExtra(Constants.EXTRA_DOCUMENT_ID, docId.trim());
            startActivity(intent);
            finish();
        } catch (Exception e) {
            Log.e("CheckoutScanner", "Navigation failed", e);
            isProcessing = false;
            Toast.makeText(this, "Error opening detail", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (scanner != null) {
            scanner.close();
        }
        if (analysisExecutor != null) {
            analysisExecutor.shutdown();
        }
    }
}
