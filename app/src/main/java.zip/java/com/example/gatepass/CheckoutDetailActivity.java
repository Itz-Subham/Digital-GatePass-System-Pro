package com.example.gatepass;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class CheckoutDetailActivity extends AppCompatActivity {

    private TextView tvStudentName, tvStudentReg, tvParentName, tvEntryTime;
    private MaterialButton btnConfirmCheckout, btnCancel;
    private FirebaseFirestore db;
    private String documentId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_checkout_detail);

        db = FirebaseFirestore.getInstance();
        documentId = getIntent().getStringExtra("DOCUMENT_ID");

        tvStudentName = findViewById(R.id.tvStudentName);
        tvStudentReg = findViewById(R.id.tvStudentReg);
        tvParentName = findViewById(R.id.tvParentName);
        tvEntryTime = findViewById(R.id.tvEntryTime);
        btnConfirmCheckout = findViewById(R.id.btnConfirmCheckout);
        btnCancel = findViewById(R.id.btnCancel);

        findViewById(R.id.btnBack).setOnClickListener(v -> finish());
        btnCancel.setOnClickListener(v -> finish());

        loadVisitorDetails();

        btnConfirmCheckout.setOnClickListener(v -> performCheckout());
    }

    private void loadVisitorDetails() {
        if (documentId == null) return;

        db.collection(Constants.COL_VISITORS).document(documentId).get()
                .addOnSuccessListener(documentSnapshot -> {
                    if (documentSnapshot.exists()) {
                        tvStudentName.setText(documentSnapshot.getString("studentName"));
                        tvStudentReg.setText("Reg No: " + documentSnapshot.getString("studentReg"));
                        tvParentName.setText(documentSnapshot.getString("parentName"));
                        
                        // Handle potential Timestamp from Firebase
                        Object entryObj = documentSnapshot.get("entryTime");
                        if (entryObj instanceof com.google.firebase.Timestamp) {
                             java.util.Date date = ((com.google.firebase.Timestamp) entryObj).toDate();
                             tvEntryTime.setText("Entry: " + DateTimeUtils.formatHeaderDate(date));
                        } else {
                             tvEntryTime.setText("Entry: " + documentSnapshot.getString("entryTime"));
                        }
                    } else {
                        Toast.makeText(this, "Visitor not found", Toast.LENGTH_SHORT).show();
                        finish();
                    }
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(this, "Error loading details", Toast.LENGTH_SHORT).show();
                    finish();
                });
    }

    private void performCheckout() {
        Map<String, Object> updates = new HashMap<>();
        updates.put("status", Constants.STATUS_LEFT);
        updates.put("exitTime", DateTimeUtils.getCurrentTime());
        updates.put("exitTimestamp", com.google.firebase.Timestamp.now());

        db.collection(Constants.COL_VISITORS).document(documentId)
                .update(updates)
                .addOnSuccessListener(aVoid -> {
                    Toast.makeText(this, "Checkout Successful", Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(this, DashboardActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(intent);
                    finish();
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(this, "Checkout Failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });
    }
}
