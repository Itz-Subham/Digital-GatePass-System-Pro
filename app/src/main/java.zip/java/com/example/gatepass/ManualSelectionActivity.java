package com.example.gatepass;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ManualSelectionActivity extends AppCompatActivity {

    public static final String ACTION_CHECKOUT = "CHECKOUT";
    public static final String ACTION_BLACKLIST = "BLACKLIST";

    private RecyclerView recyclerView;
    private VisitorAdapter adapter;
    private List<Visitor> visitorList = new ArrayList<>();
    private List<String> docIds = new ArrayList<>();
    private FirebaseFirestore db;
    private String currentAction;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manual_selection);

        db = FirebaseFirestore.getInstance();
        currentAction = getIntent().getStringExtra("ACTION");
        if (currentAction == null) currentAction = ACTION_CHECKOUT;

        TextView tvTitle = findViewById(R.id.tvSelectionTitle);
        tvTitle.setText(currentAction.equals(ACTION_CHECKOUT) ? "Manual Checkout" : "Select to Blacklist");

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        
        adapter = new VisitorAdapter(visitorList, docIds, (visitor, docId) -> {
            if (ACTION_CHECKOUT.equals(currentAction)) {
                Intent intent = new Intent(this, CheckoutDetailActivity.class);
                intent.putExtra("DOCUMENT_ID", docId);
                startActivity(intent);
                finish();
            } else if (ACTION_BLACKLIST.equals(currentAction)) {
                confirmBlacklist(visitor, docId);
            }
        });
        recyclerView.setAdapter(adapter);

        SearchView searchView = findViewById(R.id.searchView);
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                performSearch(query);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                if (newText.length() > 1) {
                    performSearch(newText);
                }
                return false;
            }
        });

        findViewById(R.id.btnBack).setOnClickListener(v -> finish());
        
        // Initial fetch: if checkout, show inside people
        if (ACTION_CHECKOUT.equals(currentAction)) {
            fetchInsideVisitors();
        }
    }

    private void fetchInsideVisitors() {
        db.collection("visitors")
                .whereEqualTo("exitTime", "pending")
                .get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    visitorList.clear();
                    docIds.clear();
                    for (QueryDocumentSnapshot doc : queryDocumentSnapshots) {
                        visitorList.add(doc.toObject(Visitor.class));
                        docIds.add(doc.getId());
                    }
                    adapter.updateList(new ArrayList<>(visitorList), new ArrayList<>(docIds));
                });
    }

    private void performSearch(String query) {
        db.collection("visitors")
                .get() // In production, use indexed search or pagination
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    visitorList.clear();
                    docIds.clear();
                    String lowerQuery = query.toLowerCase();
                    for (QueryDocumentSnapshot doc : queryDocumentSnapshots) {
                        Visitor v = doc.toObject(Visitor.class);
                        if (v.studentName.toLowerCase().contains(lowerQuery) || 
                            v.studentReg.toLowerCase().contains(lowerQuery) ||
                            v.parentName.toLowerCase().contains(lowerQuery)) {
                            
                            // If checkout action, only show those who are inside
                            if (ACTION_CHECKOUT.equals(currentAction)) {
                                if ("pending".equals(v.exitTime)) {
                                    visitorList.add(v);
                                    docIds.add(doc.getId());
                                }
                            } else {
                                visitorList.add(v);
                                docIds.add(doc.getId());
                            }
                        }
                    }
                    adapter.updateList(new ArrayList<>(visitorList), new ArrayList<>(docIds));
                });
    }

    private void confirmBlacklist(Visitor visitor, String docId) {
        new AlertDialog.Builder(this)
                .setTitle("Confirm Restriction")
                .setMessage("Add " + visitor.parentName + " to the security restricted list?")
                .setPositiveButton("Blacklist", (dialog, which) -> {
                    Map<String, Object> data = new HashMap<>();
                    data.put("name", visitor.parentName);
                    data.put("id", visitor.parentIdHash); // Fixed: changed parentId to parentIdHash
                    db.collection("blacklist").add(data)
                            .addOnSuccessListener(doc -> {
                                Toast.makeText(this, "Added to Blacklist", Toast.LENGTH_SHORT).show();
                                finish();
                            });
                })
                .setNegativeButton("Cancel", null)
                .show();
    }
}
