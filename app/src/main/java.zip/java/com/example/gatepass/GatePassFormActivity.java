package com.example.gatepass;

import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.browser.customtabs.CustomTabsIntent;
import androidx.core.content.ContextCompat;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.Timestamp;
import com.google.firebase.firestore.FirebaseFirestore;

import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;
import java.util.Date;
import java.util.Locale;

public class GatePassFormActivity extends AppCompatActivity {

    private TextInputEditText etParentName, etEntryTime, etStudentReg, etStudentName;
    private TextInputLayout tilStudentReg, tilStudentName;
    private MaterialButton btnSubmit;
    private View pbLoading;
    private TextView tvBlacklistWarning;
    private FirebaseFirestore db;
    private boolean isStudentVerified = false;

    // This will now hold ONLY the SHA-256 hash, never the raw ID
    private String parentIdHash = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gate_pass_form);

        // Bindings
        ImageView btnBack = findViewById(R.id.btnBack);
        etParentName = findViewById(R.id.etParentName);
        etEntryTime = findViewById(R.id.etEntryTime);
        etStudentReg = findViewById(R.id.etStudentReg);
        etStudentName = findViewById(R.id.etStudentName);
        tilStudentReg = findViewById(R.id.tilStudentReg);
        tilStudentName = findViewById(R.id.tilStudentName);
        btnSubmit = findViewById(R.id.btnSubmit);
        pbLoading = findViewById(R.id.pbLoading);
        tvBlacklistWarning = findViewById(R.id.tvBlacklistWarning);

        btnBack.setOnClickListener(v -> finish());
        db = FirebaseFirestore.getInstance();

        setupStudentLookup();

        // 1. Catch intent data safely
        String parentName = getIntent().getStringExtra(Constants.EXTRA_PARENT_NAME);
        String rawParentId = getIntent().getStringExtra(Constants.EXTRA_PARENT_ID);

        // 2. Hash the ID immediately. Zero retention of raw data.
        if (rawParentId != null && !rawParentId.isEmpty()) {
            parentIdHash = HashUtils.hashAadhaar(rawParentId);
        }

        // 3. Populate known fields
        if (parentName != null && !parentName.isEmpty()) {
            etParentName.setText(parentName);
            checkBlacklist(parentName);
        }

        String currentTime = new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date());
        etEntryTime.setText(currentTime);

        btnSubmit.setOnClickListener(v -> saveGateLog());

        etParentName.setOnFocusChangeListener((v, hasFocus) -> {
            if (!hasFocus) {
                checkBlacklist(etParentName.getText().toString().trim());
            }
        });
    }

    private void setupStudentLookup() {
        etStudentReg.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                isStudentVerified = false; // Reset verification on change
                tilStudentReg.setHelperText(null);
            }

            @Override
            public void afterTextChanged(Editable s) {
                String reg = s.toString().trim();
                if (reg.length() >= 3) {
                    db.collection(Constants.COL_STUDENTS)
                            .whereEqualTo("regNo", reg)
                            .limit(1)
                            .get()
                            .addOnSuccessListener(snapshots -> {
                                if (!snapshots.isEmpty()) {
                                    String name = snapshots.getDocuments().get(0).getString("name");
                                    etStudentName.setText(name);
                                    tilStudentReg.setHelperText("Student Verified: " + name);
                                    tilStudentReg.setError(null);
                                    isStudentVerified = true;
                                } else {
                                    tilStudentReg.setError("Student not found in database");
                                    isStudentVerified = false;
                                }
                            });
                }
            }
        });
    }

    private void checkBlacklist(String name) {
        if (name == null || name.isEmpty()) return;

        db.collection(Constants.COL_BLACKLIST)
                .whereEqualTo("name", name)
                .limit(1)
                .get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    if (!queryDocumentSnapshots.isEmpty()) {
                        tvBlacklistWarning.setVisibility(View.VISIBLE);
                        tvBlacklistWarning.setText("WARNING: This individual is on the security restricted list!");
                        tvBlacklistWarning.setTextColor(Color.RED);
                    } else {
                        tvBlacklistWarning.setVisibility(View.GONE);
                    }
                });
    }

    private void saveGateLog() {
        if (!isStudentVerified) {
            Toast.makeText(this, "Cannot issue pass: Student not verified!", Toast.LENGTH_LONG).show();
            tilStudentReg.setError("Please enter a valid Registration Number");
            return;
        }

        String pName = etParentName.getText().toString().trim();
        String eTime = etEntryTime.getText().toString().trim();
        String regNo = etStudentReg.getText().toString().trim();
        String sName = etStudentName.getText().toString().trim();

        if (regNo.isEmpty() || sName.isEmpty()) {
            Toast.makeText(this, "Please fill in all student details", Toast.LENGTH_SHORT).show();
            return;
        }

        // Set Loading State
        setLoading(true);

        // Use a HashMap to ensure exact key matching with the web portal
        Map<String, Object> visitorData = new HashMap<>();
        visitorData.put("studentName", sName);
        visitorData.put("studentReg", regNo);
        visitorData.put("parentName", pName);
        visitorData.put("parentIdHash", parentIdHash);
        visitorData.put("entryTime", Timestamp.now()); // Using Firebase Timestamp for the portal
        visitorData.put("status", Constants.STATUS_INSIDE);

        db.collection(Constants.COL_VISITORS)
                .add(visitorData)
                .addOnSuccessListener(documentReference -> {
                    setLoading(false);
                    Toast.makeText(this, "Gate Pass Saved Successfully", Toast.LENGTH_SHORT).show();

                    Intent intent = new Intent(this, DisplayQrActivity.class);
                    intent.putExtra(Constants.EXTRA_STUDENT_NAME, sName);
                    intent.putExtra(Constants.EXTRA_STUDENT_REG, regNo);
                    intent.putExtra(Constants.EXTRA_ENTRY_TIME, eTime);
                    intent.putExtra(Constants.EXTRA_DOCUMENT_ID, documentReference.getId());
                    startActivity(intent);

                    finish();
                })
                .addOnFailureListener(e -> {
                    setLoading(false);
                    Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });
    }

    private void setLoading(boolean isLoading) {
        btnSubmit.setEnabled(!isLoading);
        btnSubmit.setText(isLoading ? "" : getString(R.string.generate_pass));
        pbLoading.setVisibility(isLoading ? View.VISIBLE : View.GONE);
    }

    private void openWebGatePass(String docId) {
        String baseUrl = "https://gate-pass-generator-6f165.web.app?id=";
        String finalUrl = baseUrl + docId;

        CustomTabsIntent.Builder builder = new CustomTabsIntent.Builder();
        builder.setShowTitle(true);
        
        CustomTabsIntent customTabsIntent = builder.build();
        customTabsIntent.launchUrl(this, Uri.parse(finalUrl));
    }
}