package com.example.gatepass;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SearchResultsActivity extends AppCompatActivity {

    private RecyclerView rvRestricted, rvInside, rvHistory;
    private TextView tvRestrictedHeader, tvInsideHeader, tvHistoryHeader;
    private View llNoResults;
    private VisitorAdapter insideAdapter, historyAdapter;
    private SecurityListActivity.BlacklistAdapter restrictedAdapter;
    
    private final List<Visitor> insideList = new ArrayList<>();
    private final List<Visitor> historyList = new ArrayList<>();
    private final List<Map<String, String>> restrictedList = new ArrayList<>();
    
    private FirebaseFirestore db;
    private String searchQuery;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_results);

        searchQuery = getIntent().getStringExtra("QUERY");
        if (searchQuery == null) searchQuery = "";

        db = FirebaseFirestore.getInstance();

        // Bindings
        rvRestricted = findViewById(R.id.rvRestricted);
        rvInside = findViewById(R.id.rvInside);
        rvHistory = findViewById(R.id.rvHistory);
        tvRestrictedHeader = findViewById(R.id.tvRestrictedHeader);
        tvInsideHeader = findViewById(R.id.tvInsideHeader);
        tvHistoryHeader = findViewById(R.id.tvHistoryHeader);
        llNoResults = findViewById(R.id.llNoResults);
        ImageButton btnBack = findViewById(R.id.btnBack);

        btnBack.setOnClickListener(v -> finish());

        setupRecyclerViews();
        performSearch();
    }

    private void setupRecyclerViews() {
        rvInside.setLayoutManager(new LinearLayoutManager(this));
        insideAdapter = new VisitorAdapter(insideList);
        rvInside.setAdapter(insideAdapter);

        rvHistory.setLayoutManager(new LinearLayoutManager(this));
        historyAdapter = new VisitorAdapter(historyList);
        rvHistory.setAdapter(historyAdapter);

        rvRestricted.setLayoutManager(new LinearLayoutManager(this));
        restrictedAdapter = new SecurityListActivity.BlacklistAdapter(restrictedList);
        rvRestricted.setAdapter(restrictedAdapter);
    }

    private void performSearch() {
        if (searchQuery.isEmpty()) return;

        // 1. Search Blacklist
        db.collection(Constants.COL_BLACKLIST)
                .get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    restrictedList.clear();
                    for (QueryDocumentSnapshot doc : queryDocumentSnapshots) {
                        String name = doc.getString("name");
                        String id = doc.getString("id");
                        if ((name != null && name.toLowerCase().contains(searchQuery.toLowerCase())) ||
                            (id != null && id.toLowerCase().contains(searchQuery.toLowerCase()))) {
                            Map<String, String> map = new HashMap<>();
                            map.put("name", name);
                            map.put("id", id);
                            restrictedList.add(map);
                        }
                    }
                    updateUI();
                });

        // 2. Search Visitors
        db.collection(Constants.COL_VISITORS)
                .get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    insideList.clear();
                    historyList.clear();
                    for (QueryDocumentSnapshot doc : queryDocumentSnapshots) {
                        Visitor visitor = doc.toObject(Visitor.class);
                        if (visitor.studentName.toLowerCase().contains(searchQuery.toLowerCase()) ||
                            visitor.studentReg.toLowerCase().contains(searchQuery.toLowerCase()) ||
                            visitor.parentName.toLowerCase().contains(searchQuery.toLowerCase())) {
                            
                            if (Constants.STATUS_INSIDE.equals(visitor.exitTime)) {
                                insideList.add(visitor);
                            } else {
                                historyList.add(visitor);
                            }
                        }
                    }
                    updateUI();
                });
    }

    private void updateUI() {
        boolean hasResults = false;

        if (!restrictedList.isEmpty()) {
            tvRestrictedHeader.setVisibility(View.VISIBLE);
            rvRestricted.setVisibility(View.VISIBLE);
            restrictedAdapter.notifyDataSetChanged();
            hasResults = true;
        } else {
            tvRestrictedHeader.setVisibility(View.GONE);
            rvRestricted.setVisibility(View.GONE);
        }

        if (!insideList.isEmpty()) {
            tvInsideHeader.setVisibility(View.VISIBLE);
            rvInside.setVisibility(View.VISIBLE);
            insideAdapter.updateList(new ArrayList<>(insideList));
            hasResults = true;
        } else {
            tvInsideHeader.setVisibility(View.GONE);
            rvInside.setVisibility(View.GONE);
        }

        if (!historyList.isEmpty()) {
            tvHistoryHeader.setVisibility(View.VISIBLE);
            rvHistory.setVisibility(View.VISIBLE);
            historyAdapter.updateList(new ArrayList<>(historyList));
            hasResults = true;
        } else {
            tvHistoryHeader.setVisibility(View.GONE);
            rvHistory.setVisibility(View.GONE);
        }

        llNoResults.setVisibility(hasResults ? View.GONE : View.VISIBLE);
    }
}