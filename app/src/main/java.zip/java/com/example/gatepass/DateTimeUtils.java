package com.example.gatepass;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Utility for date and time formatting to ensure consistency across UI and persistence.
 */
public class DateTimeUtils {

    private static final SimpleDateFormat TIME_FORMAT = new SimpleDateFormat("HH:mm:ss", Locale.getDefault());
    private static final SimpleDateFormat DATE_TIME_FORMAT = new SimpleDateFormat("MMM dd, hh:mm a", Locale.getDefault());

    /**
     * Returns the current time in HH:mm:ss format.
     */
    public static String getCurrentTime() {
        return TIME_FORMAT.format(new Date());
    }

    /**
     * Formats a date for the dashboard header.
     */
    public static String formatHeaderDate(Date date) {
        if (date == null) return "";
        return DATE_TIME_FORMAT.format(date);
    }
}