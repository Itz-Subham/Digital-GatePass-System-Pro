package com.example.gatepass;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.print.PrintHelper;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;

public class PrintManager {

    public static void printGatePass(Context context, Visitor visitor, String documentId) {
        // 1. Inflate the slip layout
        View view = LayoutInflater.from(context).inflate(R.layout.view_gate_pass_slip, null);
        
        // 2. Populate data
        ((TextView) view.findViewById(R.id.slipStudentName)).setText("Student: " + visitor.getStudentName());
        ((TextView) view.findViewById(R.id.slipStudentReg)).setText("Reg No: " + visitor.getStudentReg());
        ((TextView) view.findViewById(R.id.slipParentName)).setText("Parent: " + visitor.getParentName());
        ((TextView) view.findViewById(R.id.slipEntryTime)).setText("Entry: " + visitor.getEntryTime());
        ((TextView) view.findViewById(R.id.slipDocId)).setText("ID: " + documentId);
        
        ImageView ivQr = view.findViewById(R.id.slipQrCode);
        Bitmap qr = generateQRCode(documentId);
        if (qr != null) ivQr.setImageBitmap(qr);

        // 3. Measure and Layout the view (Adjusted for Thermal Paper width)
        // Standard thermal width is 384px to 576px. We use 400 for safety.
        view.measure(View.MeasureSpec.makeMeasureSpec(400, View.MeasureSpec.EXACTLY),
                     View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED));
        view.layout(0, 0, view.getMeasuredWidth(), view.getMeasuredHeight());

        // 4. Create Bitmap
        Bitmap bitmap = Bitmap.createBitmap(view.getMeasuredWidth(), view.getMeasuredHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        view.draw(canvas);

        // 5. Use Android PrintHelper to send to printer
        PrintHelper photoPrinter = new PrintHelper(context);
        photoPrinter.setScaleMode(PrintHelper.SCALE_MODE_FIT);
        // Ensure it doesn't try to fit it into a giant 'Letter' page with white space
        photoPrinter.printBitmap("GatePass_" + visitor.getStudentReg(), bitmap);
    }

    private static Bitmap generateQRCode(String text) {
        QRCodeWriter writer = new QRCodeWriter();
        try {
            BitMatrix bitMatrix = writer.encode(text, BarcodeFormat.QR_CODE, 400, 400);
            int width = bitMatrix.getWidth();
            int height = bitMatrix.getHeight();
            Bitmap bmp = Bitmap.createBitmap(width, height, Bitmap.Config.RGB_565);
            for (int x = 0; x < width; x++) {
                for (int y = 0; y < height; y++) {
                    bmp.setPixel(x, y, bitMatrix.get(x, y) ? 0xFF000000 : 0xFFFFFFFF);
                }
            }
            return bmp;
        } catch (WriterException e) {
            return null;
        }
    }
}