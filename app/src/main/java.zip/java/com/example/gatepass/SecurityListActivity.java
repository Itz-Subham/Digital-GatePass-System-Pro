package com.example.gatepass;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SecurityListActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private BlacklistAdapter adapter;
    private List<Map<String, String>> blacklist;
    private FirebaseFirestore db;
    private View llEmptyState;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_security_list);

        recyclerView = findViewById(R.id.recyclerView);
        llEmptyState = findViewById(R.id.llEmptyState);
        FloatingActionButton fab = findViewById(R.id.fabAddBlacklist);
        ImageView btnBack = findViewById(R.id.btnBack);

        btnBack.setOnClickListener(v -> finish());

        blacklist = new ArrayList<>();
        adapter = new BlacklistAdapter(blacklist);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        db = FirebaseFirestore.getInstance();
        fetchBlacklist();

        fab.setOnClickListener(v -> showAddOptionDialog());
    }

    private void fetchBlacklist() {
        db.collection(Constants.COL_BLACKLIST)
                .addSnapshotListener((value, error) -> {
                    if (error != null) return;
                    blacklist.clear();
                    if (value != null) {
                        for (QueryDocumentSnapshot doc : value) {
                            Map<String, String> item = new HashMap<>();
                            item.put("name", doc.getString("name"));
                            item.put("id", doc.getString("id"));
                            blacklist.add(item);
                        }
                    }
                    adapter.notifyDataSetChanged();
                    llEmptyState.setVisibility(blacklist.isEmpty() ? View.VISIBLE : View.GONE);
                });
    }

    private void showAddOptionDialog() {
        String[] options = {"Search Existing Visitors", "Manual Entry"};
        new AlertDialog.Builder(this)
                .setTitle("Add to Restricted List")
                .setItems(options, (dialog, which) -> {
                    if (which == 0) {
                        // Open ManualSelectionActivity for blacklisting
                        Intent intent = new Intent(this, ManualSelectionActivity.class);
                        intent.putExtra("ACTION", ManualSelectionActivity.ACTION_BLACKLIST);
                        startActivity(intent);
                    } else {
                        showManualAddDialog();
                    }
                })
                .show();
    }

    private void showManualAddDialog() {
        View view = LayoutInflater.from(this).inflate(R.layout.dialog_add_blacklist, null);
        EditText etName = view.findViewById(R.id.etName);
        EditText etId = view.findViewById(R.id.etId);

        new AlertDialog.Builder(this)
                .setTitle("Manual Restricted Entry")
                .setView(view)
                .setPositiveButton("Add", (dialog, which) -> {
                    String name = etName.getText().toString().trim();
                    String id = etId.getText().toString().trim();
                    if (!name.isEmpty()) {
                        addToBlacklist(name, id);
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void addToBlacklist(String name, String rawId) {
        Map<String, Object> data = new HashMap<>();
        data.put("name", name);
        data.put("id", HashUtils.hashAadhaar(rawId));

        db.collection(Constants.COL_BLACKLIST).add(data)
                .addOnSuccessListener(doc -> Toast.makeText(this, "Added to Restricted List", Toast.LENGTH_SHORT).show());
    }

    static class BlacklistAdapter extends RecyclerView.Adapter<BlacklistAdapter.ViewHolder> {
        List<Map<String, String>> data;

        BlacklistAdapter(List<Map<String, String>> data) { this.data = data; }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_blacklist, parent, false);
            return new ViewHolder(v);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            holder.tvName.setText(data.get(position).get("name"));
            holder.tvId.setText("ID (Hashed): " + data.get(position).get("id"));
        }

        @Override
        public int getItemCount() { return data.size(); }

        static class ViewHolder extends RecyclerView.ViewHolder {
            TextView tvName, tvId;
            ViewHolder(View v) {
                super(v);
                tvName = v.findViewById(R.id.tvName);
                tvId = v.findViewById(R.id.tvId);
            }
        }
    }
}
