package com.example.gatepass;

import com.google.firebase.Timestamp;

public class Visitor {
    public String parentName;
    public String parentIdHash;
    public String studentReg;
    public String studentName;
    public Object entryTime; // Changed to Object to handle both String and Timestamp
    public String status;
    public long timestamp;
    public long exitTimestamp;
    public String exitTime;

    public Visitor() {
        // Required empty constructor for Firestore
    }

    public Visitor(String parentName, String parentIdHash, String studentReg, String studentName, Object entryTime, String status, long timestamp) {
        this.parentName = parentName;
        this.parentIdHash = parentIdHash;
        this.studentReg = studentReg;
        this.studentName = studentName;
        this.entryTime = entryTime;
        this.status = status;
        this.timestamp = timestamp;
    }

    public String getParentName() { return parentName; }
    public String getParentIdHash() { return parentIdHash; }
    public String getStudentReg() { return studentReg; }
    public String getStudentName() { return studentName; }
    
    // Helper to always get entryTime as a readable string
    public String getEntryTime() { 
        if (entryTime instanceof Timestamp) {
            return DateTimeUtils.formatHeaderDate(((Timestamp) entryTime).toDate());
        }
        return entryTime != null ? entryTime.toString() : ""; 
    }
    
    public String getStatus() { return status; }
    public long getTimestamp() { return timestamp; }
    public String getExitTime() { return exitTime; }
}