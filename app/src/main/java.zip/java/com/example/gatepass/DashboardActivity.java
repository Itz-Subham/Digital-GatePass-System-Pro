package com.example.gatepass;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.ListenerRegistration;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class DashboardActivity extends AppCompatActivity {

    private TextView tvDateTime, tvTodayEntries, tvActiveInside;
    private RecyclerView rvLiveSearch;
    private LiveSearchAdapter searchAdapter;
    private List<SearchResult> searchResults = new ArrayList<>();
    
    private FirebaseFirestore db;
    private ListenerRegistration gateLogsListener;

    private final Handler searchHandler = new Handler(Looper.getMainLooper());
    private Runnable searchRunnable;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        View mainLayout = findViewById(R.id.main);
        if (mainLayout != null) {
            ViewCompat.setOnApplyWindowInsetsListener(mainLayout, (v, insets) -> {
                Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
                v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
                return insets;
            });
        }

        tvDateTime = findViewById(R.id.tvDateTime);
        tvTodayEntries = findViewById(R.id.tvTodayEntries);
        tvActiveInside = findViewById(R.id.tvActiveInside);
        SearchView searchView = findViewById(R.id.searchView);
        rvLiveSearch = findViewById(R.id.rvLiveSearch);

        updateHeaderStatus();

        db = FirebaseFirestore.getInstance();
        setupRealTimeCounters();

        searchAdapter = new LiveSearchAdapter(searchResults, result -> {
            if ("RESTRICTED".equals(result.status)) {
                showRestrictedWarning(result);
            } else {
                openPassPreview(result);
            }
        });
        rvLiveSearch.setLayoutManager(new LinearLayoutManager(this));
        rvLiveSearch.setAdapter(searchAdapter);

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                performLiveSearch(query);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                if (searchRunnable != null) {
                    searchHandler.removeCallbacks(searchRunnable);
                }

                if (newText.length() > 1) {
                    searchRunnable = () -> performLiveSearch(newText);
                    searchHandler.postDelayed(searchRunnable, 300); // 300ms debounce
                } else {
                    searchResults.clear();
                    searchAdapter.notifyDataSetChanged();
                    rvLiveSearch.setVisibility(View.GONE);
                }
                return false;
            }
        });

        findViewById(R.id.cardScan).setOnClickListener(v -> startActivity(new Intent(this, MainActivity.class)));
        findViewById(R.id.btnManualForm).setOnClickListener(v -> startActivity(new Intent(this, GatePassFormActivity.class)));
        findViewById(R.id.btnCheckout).setOnClickListener(v -> startActivity(new Intent(this, CheckoutScannerActivity.class)));
        findViewById(R.id.btnActiveList).setOnClickListener(v -> startActivity(new Intent(this, ActiveVisitorsActivity.class)));
        findViewById(R.id.btnVisitorHistory).setOnClickListener(v -> startActivity(new Intent(this, HistoryActivity.class)));
        findViewById(R.id.btnBlacklist).setOnClickListener(v -> startActivity(new Intent(this, SecurityListActivity.class)));
        findViewById(R.id.btnAdminPanel).setOnClickListener(v -> startActivity(new Intent(this, AdminActivity.class)));
    }

    private void performLiveSearch(String query) {
        String lowerQuery = query.toLowerCase();
        
        // Optimize: Use Firestore's prefix matching where possible (on name)
        db.collection(Constants.COL_VISITORS)
                .whereGreaterThanOrEqualTo("parentName", query)
                .whereLessThanOrEqualTo("parentName", query + "\uf8ff")
                .limit(10) // Optimization: Limit results
                .get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    searchResults.clear();
                    for (QueryDocumentSnapshot doc : queryDocumentSnapshots) {
                        String name = doc.getString("parentName");
                        String reg = doc.getString("studentReg");
                        String currentStatus = doc.getString("status");
                        String displayStatus = Constants.STATUS_INSIDE.equals(currentStatus) ? "Inside" : "Left";
                        
                        searchResults.add(new SearchResult(doc.getId(), name, reg, displayStatus, doc.getString("studentName"), ""));
                    }
                    
                    if (searchResults.isEmpty()) {
                         db.collection(Constants.COL_VISITORS)
                            .whereGreaterThanOrEqualTo("studentReg", query)
                            .whereLessThanOrEqualTo("studentReg", query + "\uf8ff")
                            .limit(10)
                            .get()
                            .addOnSuccessListener(regSnapshots -> {
                                for (QueryDocumentSnapshot doc : regSnapshots) {
                                    String name = doc.getString("parentName");
                                    String reg = doc.getString("studentReg");
                                    String currentStatus = doc.getString("status");
                                    String displayStatus = Constants.STATUS_INSIDE.equals(currentStatus) ? "Inside" : "Left";
                                    searchResults.add(new SearchResult(doc.getId(), name, reg, displayStatus, doc.getString("studentName"), ""));
                                }
                                searchBlacklist(lowerQuery);
                            });
                    } else {
                        searchBlacklist(lowerQuery);
                    }
                });
    }

    private void searchBlacklist(String lowerQuery) {
        db.collection(Constants.COL_BLACKLIST)
                .limit(5)
                .get()
                .addOnSuccessListener(blacklistSnapshots -> {
                    for (QueryDocumentSnapshot doc : blacklistSnapshots) {
                        String name = doc.getString("name");
                        String id = doc.getString("id");
                        if (name != null && name.toLowerCase().contains(lowerQuery)) {
                            searchResults.add(0, new SearchResult(doc.getId(), name, "ID: " + id, "RESTRICTED", "", ""));
                        }
                    }
                    searchAdapter.notifyDataSetChanged();
                    rvLiveSearch.setVisibility(searchResults.isEmpty() ? View.GONE : View.VISIBLE);
                });
    }

    private void showRestrictedWarning(SearchResult result) {
        new AlertDialog.Builder(this)
                .setTitle("⚠️ SECURITY ALERT")
                .setMessage("RESTRICTED INDIVIDUAL: " + result.name + "\nAction: Do not issue gate pass. Contact supervisor.")
                .setPositiveButton("OK", null)
                .show();
    }

    private void openPassPreview(SearchResult result) {
        Intent intent = new Intent(this, DisplayQrActivity.class);
        intent.putExtra(Constants.EXTRA_DOCUMENT_ID, result.id);
        intent.putExtra(Constants.EXTRA_STUDENT_NAME, result.studentName);
        intent.putExtra(Constants.EXTRA_STUDENT_REG, result.regNo);
        intent.putExtra(Constants.EXTRA_ENTRY_TIME, result.entryTime);
        startActivity(intent);
    }

    private void setupRealTimeCounters() {
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        long startOfToday = cal.getTimeInMillis();

        gateLogsListener = db.collection(Constants.COL_VISITORS)
                .whereGreaterThanOrEqualTo("timestamp", startOfToday)
                .addSnapshotListener((value, error) -> {
                    if (error != null) {
                        Log.e("Firestore", "Listen failed.", error);
                        return;
                    }
                    int todayCount = 0;
                    int insideCount = 0;

                    if (value != null) {
                        todayCount = value.size(); // Already filtered by timestamp
                        for (QueryDocumentSnapshot doc : value) {
                            if (Constants.STATUS_INSIDE.equals(doc.getString("status"))) {
                                insideCount++;
                            }
                        }
                    }
                    tvTodayEntries.setText(String.valueOf(todayCount));
                    tvActiveInside.setText(String.valueOf(insideCount));
                });
    }

    private void updateHeaderStatus() {
        tvDateTime.setText(DateTimeUtils.formatHeaderDate(new Date()));
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateHeaderStatus();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (gateLogsListener != null) gateLogsListener.remove();
    }

    public static class SearchResult {
        String id, name, regNo, status, studentName, entryTime;
        SearchResult(String id, String name, String regNo, String status, String studentName, String entryTime) {
            this.id = id; this.name = name; this.regNo = regNo; this.status = status;
            this.studentName = studentName; this.entryTime = entryTime;
        }
    }

    public static class LiveSearchAdapter extends RecyclerView.Adapter<LiveSearchAdapter.ViewHolder> {
        private final List<SearchResult> results;
        private final OnResultClickListener listener;

        public interface OnResultClickListener { void onClick(SearchResult result); }

        LiveSearchAdapter(List<SearchResult> results, OnResultClickListener listener) {
            this.results = results; this.listener = listener;
        }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_live_search, parent, false);
            return new ViewHolder(v);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            SearchResult res = results.get(position);
            holder.tvName.setText(res.name);
            holder.tvReg.setText(String.format("Reg: %s", res.regNo));
            holder.tvStatus.setText(res.status);
            
            if ("RESTRICTED".equals(res.status)) {
                holder.tvStatus.setBackgroundColor(Color.RED);
                holder.tvStatus.setTextColor(Color.WHITE);
                holder.itemView.setBackgroundColor(Color.parseColor("#33FF0000"));
            } else if ("Inside".equals(res.status)) {
                holder.tvStatus.setBackgroundColor(Color.parseColor("#4CAF50")); // Green
                holder.tvStatus.setTextColor(Color.WHITE);
                holder.itemView.setBackgroundColor(Color.TRANSPARENT);
            } else {
                holder.tvStatus.setBackgroundColor(Color.parseColor("#424242")); // Dark Gray
                holder.tvStatus.setTextColor(Color.WHITE);
                holder.itemView.setBackgroundColor(Color.TRANSPARENT);
            }
            holder.itemView.setOnClickListener(v -> listener.onClick(res));
        }

        @Override
        public int getItemCount() { return results.size(); }

        static class ViewHolder extends RecyclerView.ViewHolder {
            TextView tvName, tvReg, tvStatus;
            ViewHolder(View v) {
                super(v);
                tvName = v.findViewById(R.id.tvName);
                tvReg = v.findViewById(R.id.tvRegNo);
                tvStatus = v.findViewById(R.id.tvStatus);
            }
        }
    }
}
