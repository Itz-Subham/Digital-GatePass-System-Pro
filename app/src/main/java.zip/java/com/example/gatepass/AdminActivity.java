package com.example.gatepass;

import android.os.Bundle;
import android.os.Environment;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.gatepass.R;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class AdminActivity extends AppCompatActivity {

    private Button btnExportCSV;
    private TextView tvStatus;
    private FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);

        btnExportCSV = findViewById(R.id.btnExportCsv);
        tvStatus = findViewById(R.id.tvStatus);

        db = FirebaseFirestore.getInstance();

        if (btnExportCSV != null) {
            btnExportCSV.setOnClickListener(v -> exportDataToCSV());
        }

        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Admin Panel");
        }

        findViewById(R.id.btnBack).setOnClickListener(v -> finish());
    }

    private void exportDataToCSV() {
        db.collection("visitors")
            .get()
            .addOnSuccessListener(queryDocumentSnapshots -> {
                StringBuilder csvData = new StringBuilder();
                csvData.append("ParentName,ParentID,StudentReg,StudentName,EntryTime,ExitTime,Timestamp\n");

                for (QueryDocumentSnapshot doc : queryDocumentSnapshots) {
                    csvData.append(doc.getString("parentName")).append(",");
                    csvData.append(doc.getString("parentId")).append(",");
                    csvData.append(doc.getString("studentReg")).append(",");
                    csvData.append(doc.getString("studentName")).append(",");
                    csvData.append(doc.getString("entryTime")).append(",");
                    csvData.append(doc.getString("exitTime")).append(",");
                    csvData.append(doc.getLong("timestamp")).append("\n");
                }

                saveFileToStorage(csvData.toString());
            })
            .addOnFailureListener(e -> {
                Toast.makeText(this, "Export Failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            });
    }

    private void saveFileToStorage(String data) {
        String filename = "GatePassLogs_" + System.currentTimeMillis() + ".csv";
        File file = new File(getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS), filename);

        try (FileWriter writer = new FileWriter(file)) {
            writer.append(data);
            tvStatus.setText("Exported to: " + file.getAbsolutePath());
            Toast.makeText(this, "CSV Exported Successfully", Toast.LENGTH_SHORT).show();
        } catch (IOException e) {
            Toast.makeText(this, "Error saving file", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
}
