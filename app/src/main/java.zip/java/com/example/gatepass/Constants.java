package com.example.gatepass;

import java.util.regex.Pattern;

/**
 * Central repository for constants used across the application.
 * This prevents duplication and makes global changes easier.
 */
public class Constants {

    // Firestore Collections
    public static final String COL_VISITORS = "visitors";
    public static final String COL_STUDENTS = "students";
    public static final String COL_BLACKLIST = "blacklist";

    // Web App URLs
    public static final String BASE_QR_URL = "https://gate-pass-generator-6f165.web.app?id=";

    // Intent Extras
    public static final String EXTRA_DOCUMENT_ID = "DOCUMENT_ID";
    public static final String EXTRA_STUDENT_NAME = "STUDENT_NAME";
    public static final String EXTRA_STUDENT_REG = "STUDENT_REG";
    public static final String EXTRA_PARENT_NAME = "PARENT_NAME";
    public static final String EXTRA_ENTRY_TIME = "ENTRY_TIME";
    public static final String EXTRA_PARENT_ID = "PARENT_ID";

    // Regex Patterns
    public static final Pattern AADHAAR_PATTERN = Pattern.compile("\\d{4}[\\s-]?\\d{4}[\\s-]?\\d{4}");
    public static final Pattern NAME_PATTERN = Pattern.compile("^[a-zA-Z][a-zA-Z\\s]{1,38}[a-zA-Z]$");
    public static final Pattern BLACKLIST_REGEX = Pattern.compile(
            "(?i).*(gov|govement|gavement|india|indla|unique|unlque|authority|uidai|aadhaar|aadhar|dob|" +
                    "male|female|year|birth|address|father|husband|wife|enrolment|vid|help|www|http|phone|mobile).*"
    );

    // Status Constants
    public static final String STATUS_INSIDE = "pending";
    public static final String STATUS_LEFT = "Left";
    public static final String STATUS_CHECKED_OUT = "CHECKED_OUT";

    // OCR Constants
    public static final double SIMILARITY_THRESHOLD = 0.70;
    public static final int REQUIRED_CONSENSUS = 2;
    public static final float BLUR_THRESHOLD = 4.0f;
}