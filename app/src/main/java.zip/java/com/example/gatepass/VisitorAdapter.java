package com.example.gatepass;

import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class VisitorAdapter extends RecyclerView.Adapter<VisitorAdapter.VisitorViewHolder> {

    private List<Visitor> visitors;
    private List<Visitor> visitorsFull;
    private OnVisitorClickListener listener;

    public interface OnVisitorClickListener {
        void onVisitorClick(Visitor visitor, String docId);
    }

    private List<String> docIds = new ArrayList<>();
    private List<String> docIdsFull = new ArrayList<>();

    public VisitorAdapter(List<Visitor> visitors) {
        this.visitors = visitors;
        this.visitorsFull = new ArrayList<>(visitors);
    }

    public VisitorAdapter(List<Visitor> visitors, List<String> docIds, OnVisitorClickListener listener) {
        this.visitors = visitors;
        this.visitorsFull = new ArrayList<>(visitors);
        this.docIds = docIds;
        this.docIdsFull = new ArrayList<>(docIds);
        this.listener = listener;
    }

    @NonNull
    @Override
    public VisitorViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_visitor, parent, false);
        return new VisitorViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull VisitorViewHolder holder, int position) {
        Visitor visitor = visitors.get(position);
        holder.tvStudentName.setText(visitor.studentName);
        holder.tvStudentReg.setText("Reg: " + visitor.studentReg);
        holder.tvParentName.setText("Visitor: " + visitor.parentName);
        
        // Status Badge Logic
        int statusColor;
        String statusText;
        String timeInfo;

        if (Constants.STATUS_INSIDE.equals(visitor.exitTime)) {
            statusText = "INSIDE";
            statusColor = Color.parseColor("#4CAF50"); // status_inside
            timeInfo = "Entered: " + visitor.entryTime;
        } else {
            statusText = "LEFT";
            statusColor = Color.parseColor("#757575"); // status_left
            
            String exitTimeStr = (visitor.exitTimestamp > 0) 
                ? new SimpleDateFormat("hh:mm a", Locale.getDefault()).format(new Date(visitor.exitTimestamp))
                : visitor.exitTime;
            timeInfo = "In: " + visitor.entryTime + " | Out: " + exitTimeStr;
        }

        holder.tvStatus.setText(statusText);
        GradientDrawable badge = (GradientDrawable) holder.tvStatus.getBackground();
        if (badge == null) {
            badge = new GradientDrawable();
            badge.setCornerRadius(8f);
            holder.tvStatus.setBackground(badge);
        }
        badge.setColor(statusColor);
        holder.tvTime.setText(timeInfo);

        holder.itemView.setOnClickListener(v -> {
            if (listener != null && !docIds.isEmpty()) {
                listener.onVisitorClick(visitor, docIds.get(position));
            }
        });
    }

    @Override
    public int getItemCount() {
        return visitors.size();
    }

    public void updateList(List<Visitor> newList) {
        this.visitors = newList;
        this.visitorsFull = new ArrayList<>(newList);
        notifyDataSetChanged();
    }

    public void updateList(List<Visitor> newList, List<String> newIds) {
        this.visitors = newList;
        this.visitorsFull = new ArrayList<>(newList);
        this.docIds = newIds;
        this.docIdsFull = new ArrayList<>(newIds);
        notifyDataSetChanged();
    }

    public void filter(String text) {
        List<Visitor> filteredList = new ArrayList<>();
        List<String> filteredIds = new ArrayList<>();
        for (int i = 0; i < visitorsFull.size(); i++) {
            Visitor item = visitorsFull.get(i);
            if (item.studentName.toLowerCase().contains(text.toLowerCase()) ||
                item.studentReg.toLowerCase().contains(text.toLowerCase()) ||
                item.parentName.toLowerCase().contains(text.toLowerCase())) {
                filteredList.add(item);
                if (!docIdsFull.isEmpty()) {
                    filteredIds.add(docIdsFull.get(i));
                }
            }
        }
        visitors = filteredList;
        docIds = filteredIds;
        notifyDataSetChanged();
    }

    static class VisitorViewHolder extends RecyclerView.ViewHolder {
        TextView tvStudentName, tvStudentReg, tvParentName, tvTime, tvStatus;

        public VisitorViewHolder(@NonNull View itemView) {
            super(itemView);
            tvStudentName = itemView.findViewById(R.id.tvStudentName);
            tvStudentReg = itemView.findViewById(R.id.tvStudentReg);
            tvParentName = itemView.findViewById(R.id.tvParentName);
            tvTime = itemView.findViewById(R.id.tvTime);
            tvStatus = itemView.findViewById(R.id.tvStatus);
        }
    }
}
