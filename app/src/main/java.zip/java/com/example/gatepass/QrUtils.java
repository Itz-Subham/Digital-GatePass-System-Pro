package com.example.gatepass;

import android.graphics.Bitmap;
import android.graphics.Color;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.journeyapps.barcodescanner.BarcodeEncoder;

/**
 * Utility for generating QR code bitmaps.
 * Centralizing this ensures consistent QR styling across the app.
 */
public class QrUtils {

    /**
     * Generates a high-resolution QR code bitmap.
     * @param content The text/URL to encode.
     * @param size The pixel width/height.
     * @return Bitmap or null if encoding fails.
     */
    public static Bitmap generateQrCode(String content, int size) {
        if (content == null || content.isEmpty()) return null;
        
        MultiFormatWriter writer = new MultiFormatWriter();
        try {
            BitMatrix bitMatrix = writer.encode(content, BarcodeFormat.QR_CODE, size, size);
            BarcodeEncoder encoder = new BarcodeEncoder();
            return encoder.createBitmap(bitMatrix);
        } catch (WriterException e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * Constructs the official web pass URL for a document ID.
     */
    public static String getWebPassUrl(String docId) {
        if (docId == null) return "";
        return Constants.BASE_QR_URL + docId.trim();
    }
}