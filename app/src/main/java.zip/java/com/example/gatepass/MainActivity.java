package com.example.gatepass;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Rect;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.OptIn;
import androidx.appcompat.app.AppCompatActivity;
import androidx.camera.core.Camera;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.ExperimentalGetImage;
import androidx.camera.core.ImageAnalysis;
import androidx.camera.core.ImageProxy;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.common.util.concurrent.ListenableFuture;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity {

    private PreviewView viewFinder;
    private TextView resultTextView;
    private Button captureBtn;
    private View scanFrame;
    private FloatingActionButton torchBtn;
    private ImageView btnBack;

    private TextRecognizer recognizer;
    private Camera camera;
    private boolean isTorchOn = false;
    private boolean isProcessing = false;

    private String lastConfirmedId = "";
    private String lastConfirmedName = "";
    private final List<String> idHistory = new ArrayList<>();
    private final List<String> nameHistory = new ArrayList<>();

    private ExecutorService analysisExecutor;

    private static final int REQUIRED_CONSENSUS = Constants.REQUIRED_CONSENSUS;
    private static final double SIMILARITY_THRESHOLD = Constants.SIMILARITY_THRESHOLD;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        viewFinder      = findViewById(R.id.viewFinder);
        resultTextView  = findViewById(R.id.scanResultText);
        captureBtn      = findViewById(R.id.captureBtn);
        scanFrame       = findViewById(R.id.scan_frame);
        torchBtn        = findViewById(R.id.torchBtn);
        btnBack         = findViewById(R.id.btnBack);

        recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        analysisExecutor = Executors.newSingleThreadExecutor();

        torchBtn.setOnClickListener(v -> toggleTorch());
        btnBack.setOnClickListener(v -> finish());

        captureBtn.setOnClickListener(v -> {
            if (!lastConfirmedId.isEmpty()) {
                Intent intent = new Intent(MainActivity.this, GatePassFormActivity.class);
                intent.putExtra(Constants.EXTRA_PARENT_NAME, lastConfirmedName);
                intent.putExtra(Constants.EXTRA_PARENT_ID, lastConfirmedId);
                startActivity(intent);
            } else {
                Toast.makeText(this, "Point at Aadhaar Card", Toast.LENGTH_SHORT).show();
            }
        });

        if (allPermissionsGranted()) {
            startCamera();
        } else {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.CAMERA}, 101);
        }
    }

    private void toggleTorch() {
        if (camera != null) {
            isTorchOn = !isTorchOn;
            camera.getCameraControl().enableTorch(isTorchOn);
        }
    }

    private void startCamera() {
        ListenableFuture<ProcessCameraProvider> future = ProcessCameraProvider.getInstance(this);
        future.addListener(() -> {
            try {
                ProcessCameraProvider cameraProvider = future.get();
                Preview preview = new Preview.Builder().build();
                preview.setSurfaceProvider(viewFinder.getSurfaceProvider());

                ImageAnalysis imageAnalysis = new ImageAnalysis.Builder()
                        .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                        .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_YUV_420_888)
                        .build();
                imageAnalysis.setAnalyzer(analysisExecutor, this::processImageProxy);

                cameraProvider.unbindAll();
                camera = cameraProvider.bindToLifecycle(
                        this, CameraSelector.DEFAULT_BACK_CAMERA, preview, imageAnalysis);

            } catch (ExecutionException | InterruptedException e) {
                Log.e("CameraX", "Binding failed", e);
            }
        }, ContextCompat.getMainExecutor(this));
    }

    @OptIn(markerClass = ExperimentalGetImage.class)
    private void processImageProxy(ImageProxy imageProxy) {
        if (isProcessing || imageProxy.getImage() == null) {
            imageProxy.close();
            return;
        }

        double blurScore = calculateBlurScore(imageProxy);
        if (blurScore < Constants.BLUR_THRESHOLD) {
            updateUI("Status: Too Blurry", Color.RED);
            imageProxy.close();
            return;
        }

        isProcessing = true;
        
        // Use the native media image directly to avoid expensive conversions where possible
        InputImage image = InputImage.fromMediaImage(
                imageProxy.getImage(), 
                imageProxy.getImageInfo().getRotationDegrees()
        );

        recognizer.process(image)
                .addOnSuccessListener(this::analyzeText)
                .addOnCompleteListener(task -> {
                    isProcessing = false;
                    imageProxy.close();
                });
    }

    private void analyzeText(Text visionText) {
        String detectedId = "";
        Text.Line idLine = null;

        List<Text.TextBlock> blocks = visionText.getTextBlocks();

        for (Text.TextBlock block : blocks) {
            for (Text.Line line : block.getLines()) {
                Matcher m = Constants.AADHAAR_PATTERN.matcher(line.getText());
                if (m.find()) {
                    String raw = m.group().replaceAll("[\\s-]", "");
                    if (raw.length() == 12 && Verhoeff.validateVerhoeff(raw)) {
                        detectedId = raw;
                        idLine = line;
                        break;
                    }
                }
            }
            if (!detectedId.isEmpty()) break;
        }

        if (detectedId.isEmpty()) {
            updateUI("Scanning Aadhaar Card...", Color.YELLOW);
            return;
        }

        String detectedName = findName(idLine, blocks);

        if (!detectedName.isEmpty()) {
            runConsensus(detectedId, detectedName);
        } else {
            updateUI("ID: " + formatAadhaar(detectedId) + "\nLooking for name...", Color.YELLOW);
        }
    }

    // Stable absolute-position logic
    private String findName(Text.Line idLine, List<Text.TextBlock> allBlocks) {
        Rect idRect = idLine.getBoundingBox();
        if (idRect == null) return "";

        List<ScoredLine> candidates = new ArrayList<>();

        for (Text.TextBlock block : allBlocks) {
            for (Text.Line line : block.getLines()) {
                if (line == idLine) continue;
                Rect r = line.getBoundingBox();
                if (r == null) continue;

                if (r.bottom > idRect.top + 20) continue;

                String text = line.getText().trim();
                int score = scoreAsName(text);

                if (score > 0) {
                    int dist = idRect.top - r.bottom;
                    candidates.add(new ScoredLine(text, score, dist));
                }
            }
        }

        if (candidates.isEmpty()) return "";

        candidates.sort((a, b) -> {
            if (b.score != a.score) return b.score - a.score;
            return a.distToId - b.distToId;
        });

        return candidates.get(0).text;
    }

    private int scoreAsName(String text) {
        if (text.isEmpty() || Constants.BLACKLIST_REGEX.matcher(text).find()) return 0;

        int score = 0;
        if (Constants.NAME_PATTERN.matcher(text).matches()) score += 3;
        if (text.contains(" ")) score += 1;
        if (Objects.equals(text, text.toUpperCase())) score += 1;

        return score;
    }

    private String formatAadhaar(String id) {
        if (id == null || id.length() != 12) return id;
        return id.substring(0, 4) + " " + id.substring(4, 8) + " " + id.substring(8, 12);
    }

    private void runConsensus(String id, String name) {
        idHistory.add(id);
        nameHistory.add(name);
        if (idHistory.size() > REQUIRED_CONSENSUS) {
            idHistory.remove(0);
            nameHistory.remove(0);
        }

        if (idHistory.size() == REQUIRED_CONSENSUS) {
            int idCount = Collections.frequency(idHistory, id);
            boolean namesStable = true;
            for (String n : nameHistory) {
                if (calculateSimilarity(name, n) < SIMILARITY_THRESHOLD) {
                    namesStable = false; break;
                }
            }

            if (idCount == REQUIRED_CONSENSUS && namesStable) {
                lastConfirmedId = id;
                lastConfirmedName = name;
                updateUI("VERIFIED\nNAME: " + name + "\nID: " + formatAadhaar(id), Color.GREEN);
            } else {
                updateUI("Verifying Stability...", Color.YELLOW);
            }
        }
    }

    private double calculateBlurScore(ImageProxy image) {
        ImageProxy.PlaneProxy plane = image.getPlanes()[0];
        ByteBuffer buffer = plane.getBuffer();
        int rowStride = plane.getRowStride();
        int pixelStride = plane.getPixelStride();
        
        int w = image.getWidth();
        int h = image.getHeight();
        long sumSq = 0; 
        int count = 0;
        
        // Sample pixels efficiently without copying the entire buffer
        for (int y = 10; y < h - 10; y += 15) {
            for (int x = 10; x < w - 10; x += 15) {
                int i = y * rowStride + x * pixelStride;
                int i_minus_1 = y * rowStride + (x - 1) * pixelStride;
                int i_plus_1 = y * rowStride + (x + 1) * pixelStride;
                int i_minus_w = (y - 1) * rowStride + x * pixelStride;
                int i_plus_w = (y + 1) * rowStride + x * pixelStride;
                
                int val = buffer.get(i) & 0xFF;
                int lap = val * 4 
                        - (buffer.get(i_minus_1) & 0xFF) 
                        - (buffer.get(i_plus_1) & 0xFF) 
                        - (buffer.get(i_minus_w) & 0xFF) 
                        - (buffer.get(i_plus_w) & 0xFF);
                sumSq += (long) lap * lap; 
                count++;
            }
        }
        return (double) sumSq / count;
    }

    private double calculateSimilarity(String s1, String s2) {
        int dist = levenshtein(s1.toLowerCase(), s2.toLowerCase());
        return 1.0 - ((double) dist / Math.max(s1.length(), s2.length()));
    }

    private int levenshtein(String s1, String s2) {
        int[] costs = new int[s2.length() + 1];
        for (int i = 0; i <= s1.length(); i++) {
            int lastValue = i;
            for (int j = 0; j <= s2.length(); j++) {
                if (i == 0) costs[j] = j;
                else if (j > 0) {
                    int newValue = costs[j - 1];
                    if (s1.charAt(i - 1) != s2.charAt(j - 1)) newValue = Math.min(Math.min(newValue, lastValue), costs[j]) + 1;
                    costs[j - 1] = lastValue; lastValue = newValue;
                }
            }
            if (i > 0) costs[s2.length()] = lastValue;
        }
        return costs[s2.length()];
    }

    private void updateUI(String text, int color) {
        runOnUiThread(() -> {
            resultTextView.setText(text);
            resultTextView.setTextColor(color);
            
            // Visual feedback on the frame
            int alpha = (color == Color.GREEN) ? 80 : 45;
            scanFrame.setBackgroundColor(Color.argb(alpha, Color.red(color), Color.green(color), Color.blue(color)));
            
            // Pulse animation for verified state
            if (color == Color.GREEN) {
                scanFrame.animate().scaleX(1.05f).scaleY(1.05f).setDuration(150).withEndAction(() -> 
                    scanFrame.animate().scaleX(1.0f).scaleY(1.0f).setDuration(150).start()
                ).start();
            }
        });
    }

    private boolean allPermissionsGranted() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED;
    }

    private static class ScoredLine {
        String text;
        int score;
        int distToId;

        ScoredLine(String text, int score, int distToId) {
            this.text = text;
            this.score = score;
            this.distToId = distToId;
        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (recognizer != null) {
            recognizer.close();
        }
        if (analysisExecutor != null) {
            analysisExecutor.shutdown();
        }
    }
}
